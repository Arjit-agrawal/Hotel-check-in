package com.example.hotelcheck.listener

import com.example.hotelcheck.model.RoomModel

interface RVRoomListener {
    fun onItemClick(model : RoomModel)
}