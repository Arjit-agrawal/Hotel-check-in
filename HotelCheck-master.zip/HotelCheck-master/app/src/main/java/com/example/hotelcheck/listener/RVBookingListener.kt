package com.example.hotelcheck.listener

interface RVBookingListener {
    fun onItemClickListener(itemId : String)
}